src/filesystem/filesystem.o: src/filesystem/filesystem.c \
  src/filesystem/filesystem.h src/types/types.h
