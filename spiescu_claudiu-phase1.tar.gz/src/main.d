src/main.o: src/main.c src/types/types.h src/actions/actions.h \
  src/filesystem/filesystem.h
