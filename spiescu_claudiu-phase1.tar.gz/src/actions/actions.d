src/actions/actions.o: src/actions/actions.c src/actions/actions.h \
  src/types/types.h src/filesystem/filesystem.h
